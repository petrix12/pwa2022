﻿/* -- DO NOT REMOVE --
 * jQuery Material Toast plugin v1.1
 * 
 * Author: Dionlee Uy
 * Email: dionleeuy@gmail.com
 *
 * Date: Tue Apr 4 2017
 *
 * @requires jQuery
 * -- DO NOT REMOVE --
 */
 if (typeof jQuery === 'undefined') { throw new Error('MDToast: This plugin requires jQuery'); }
 +function ($) {
 	var MDToast = function (message, options) {
 		this.animateTime = 250;
 		this.message = message;
 		this.options = options;
 		this.toastOpenClass = "mdtoast--open";
 		this.toastModalClass = "mdtoast--modal";
 		this.TOAST_DATA = "dmu-md-toast";

 		this.toast = $('<div class="mdtoast mdt--load"></div>');
 		this.action = $('<button class="mdt-action" tabindex="0"></button>');
 		this.toastTimeout = null;

 		this.toast.addClass(options.type === 'default' ? '' : 'mdt--' + options.type)
 			.append('<div class="mdt-message">' + message + '</div>');

 		if (options.interaction) {
 			var that = this;
 			this.action.text(options.actionText)
	 			.on('click', function () {
	 				if (options.action) options.action(that);
	 			});
 			this.toast.append(this.action).addClass('mdt--interactive');
 		}

 		if (!options.init) this.show();
 	}

 	MDToast.prototype = {
 		constructor : MDToast,

 		show : function () {
 			var that = this, callbacks = that.options.callbacks, existingToast = $('.mdtoast'), doc = $('body');

 			if (that.toast.is(':visible')) return;

 			that.toast.data(that.TOAST_DATA, that).appendTo(doc);

 			setTimeout(function () {
 				that.toast.removeClass('mdt--load');

 				if (existingToast.length > 0) {
 					existingToast.each(function () {
 						var ex_toast = $(this).data(that.TOAST_DATA);

 						ex_toast.hide();
 					});
 				}

 				setTimeout(function () { if (callbacks && callbacks.shown) callbacks.shown(that); }, that.animateTime);

 				if (that.options.interaction) {
 					if (that.options.interactionTimeout)
 						that.toastTimeout = setTimeout(function () { that.hide(); }, that.options.interactionTimeout);
 				} else if (that.options.duration){
 					that.toastTimeout = setTimeout(function () { that.hide(); }, that.options.duration);
 				}

 				
 				doc.addClass(that.toastOpenClass);

 				if (that.options.modal) doc.addClass(that.toastModalClass);
 			}, 10);
 		},
 		hide: function () {
 			var that = this, callbacks = that.options.callbacks, doc = $('body');

 			clearTimeout(that.toastTimeout);

 			that.toast.addClass('mdt--load');
            doc.removeClass(that.toastOpenClass).removeClass(that.toastModalClass);
            setTimeout(function () {
                that.toast.remove();
                if(callbacks && callbacks.hidden) callbacks.hidden();
            }, that.animateTime);
 		}
 	}
	
 	$.mdtoast = function(message, options) {
 		return new MDToast(message, $.extend({}, $.mdtoast.defaults, null, typeof options === 'object' && options));
 	}

 	$.mdtoast.defaults = {
 		init: false,				// true if initalize only, false to automatically show toast after initialization.
		duration: 5000,				// duration ot toast message.
		type: 'default',			// type of toast to display (can also be info, error, warning, success)
		modal: false,				// true if you want to disable pointer events when toast is shown
		interaction: false,			// determines if toast requires user interaction to dismiss
		interactionTimeout: null,	// if requires interaction, set the value for automatic dismissal of toast (e.g. 2000 -> 2 seconds)
		actionText: 'OK',			// if requires interaction, set the value like 'UNDO'
		action: function (data) {	// callback action for the user interaction, hides toast by default
			data.hide();
		},
		callbacks: {}				// callback object for toast; contains hidden() and shown()
	};

	$.mdtoast.type = {
		INFO : 'info',
		ERROR : 'error',
		WARNING : 'warning',
		SUCCESS : 'success'		
	};

	// $.mdtoast.Constructor = MDToast;
 }(jQuery);